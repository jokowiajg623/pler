#pragma once

#define HTTP_SERVER "5.189.144.47"
#define HTTP_PORT 80

#define TFTP_SERVER "5.189.144.47"
