#pragma once

#define HTTP_SERVER "62.171.152.61"
#define HTTP_PORT 80

#define TFTP_SERVER "62.171.152.61"
