#pragma once

#define HTTP_SERVER "144.91.86.92"
#define HTTP_PORT 80

#define TFTP_SERVER "144.91.86.92"
