#pragma once

#define HTTP_SERVER "165.245.180.143"
#define HTTP_PORT 80

#define TFTP_SERVER "165.245.180.143"
