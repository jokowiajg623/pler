#ifndef MORTE_UPDATE_H
#define MORTE_UPDATE_H

void handle_update(char *buf, int len);
void enable_commands(void);
void enable_download_commands(void);

#endif
